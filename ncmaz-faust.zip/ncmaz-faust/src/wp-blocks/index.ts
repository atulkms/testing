import NcmazFaustBlockMagazine from "./NcmazFaustBlockMagazine";
import NcmazFaustBlockTerms from "./NcmazFaustBlockTerms";
import NcmazFaustBlockCta from "./NcmazFaustBlockCta";
import NcmazFaustBlockGroup from "./NcmazFaustBlockGroup";
import CoreColumns from "./CoreColumns";
import CoreColumn from "./CoreColumn";
export default {
  NcmazFaustBlockMagazine,
  NcmazFaustBlockTerms,
  NcmazFaustBlockCta,
  NcmazFaustBlockGroup,
  CoreColumns,
  CoreColumn,
};
