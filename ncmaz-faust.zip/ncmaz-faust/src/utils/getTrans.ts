import en from "../../public/lang/en";

const getTrans = () => {
  const trans = en;

  return trans;
};

export default getTrans;
