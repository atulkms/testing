import Page404Content from "@/container/404Content";

export default function NotFound() {
  return (
    <>
      <Page404Content />
    </>
  );
}
