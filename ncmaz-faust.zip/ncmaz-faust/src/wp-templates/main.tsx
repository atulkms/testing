import Page404Content from "@/container/404Content";

export default function Index() {
  return (
    <>
      <Page404Content />
    </>
  );
}
