declare module "redux-persist/lib/storage";
